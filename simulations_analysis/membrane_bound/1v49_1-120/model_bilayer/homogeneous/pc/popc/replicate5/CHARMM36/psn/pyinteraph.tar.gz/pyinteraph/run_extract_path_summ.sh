#!/bin/bash

cd contact/5.125/paths/

head -119 10ARG-16ARG/allpath/path.log | tail -2 >  contacts_paths_summary
head -119 10ARG-21ARG/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 11ARG-16ARG/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 11ARG-21ARG/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 53LEU-70ARG/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 57HIS-28PRO/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 57HIS-29THR/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 57HIS-32PRO/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 57HIS-56ASP/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 57HIS-60MET/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 57HIS-98VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -119 70ARG-70ARG/allpath/path.log | tail -2 >>  contacts_paths_summary

cd ../../../hb/all/paths/

head -119 10ARG-113TYR/allpath/path.log | tail -2 >  hb_paths_summary
head -119 10ARG-16ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-19ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-21ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-29THR/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-32PRO/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-56ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-60MET/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-65LYS/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-70ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-91VAL/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 10ARG-98VAL/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-113TYR/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-16ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-19ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-21ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-29THR/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-32PRO/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-56ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-60MET/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-70ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 11ARG-98VAL/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 70ARG-113TYR/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 70ARG-16ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 70ARG-60MET/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 70ARG-65LYS/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 70ARG-70ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 70ARG-91VAL/allpath/path.log | tail -2 >>  hb_paths_summary
head -119 70ARG-98VAL/allpath/path.log | tail -2 >>  hb_paths_summary


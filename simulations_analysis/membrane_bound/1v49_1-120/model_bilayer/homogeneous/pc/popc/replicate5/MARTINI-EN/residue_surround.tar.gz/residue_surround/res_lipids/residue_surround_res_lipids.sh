#!/bin/bash
#bash script for the analysis of the proximity between the protein and the membrane i.e. calculation of the number of lipid atoms in the surround of each residues of the protein   
#always remember to have the right residuetypes.dat file in the local folder
#define the name of the reference xtc and tpr file
residuetypes=../../../../../../../../../../../../../simulations/lc3b/membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate5/MARTINI-EN/md/prot_memb/residuetypes.dat
xtc=../../../../../../../../../../../../../simulations/lc3b/membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate5/MARTINI-EN/md/prot_memb/center_traj_prot_memb.xtc
tpr=../../../../../../../../../../../../../simulations/lc3b/membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate5/MARTINI-EN/md/prot_memb/md_prot_memb.tpr
# calculation of the number of lipid atoms, i.e. group "POPC", in a spherical sourround with 0.6 A of radius around the center of mass of each residue
# To do the calculation we use a for cycle and the gromacs tool gmx select

for ((i=1; i <=120; i++)); do
mkdir $i
cd $i
cp $residuetypes .
gmx_mpi select -f $xtc -s $tpr -os $i.POPC.atoms -select 'group "POPC" and same residue as within 0.6 of resnr '$i''
cd ..
done

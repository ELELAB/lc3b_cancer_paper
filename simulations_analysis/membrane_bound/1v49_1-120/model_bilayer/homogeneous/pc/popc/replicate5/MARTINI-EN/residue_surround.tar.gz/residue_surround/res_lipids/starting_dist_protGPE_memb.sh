#!/bin/bash
#bash script for the analysis of the starting distance between the protein and the membrane 
#always remember to have the right residuetypes.dat file in the local folder
#define the name of the reference pdb file
residuetypes=../../../../../../../../../../../../simulations/lc3b/membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate5/MARTINI-EN/pre_md/0/residuetypes.dat 
pdb=../../../../../../../../../../../../simulations/lc3b/membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate5/MARTINI-EN/pre_md/0/step5_charmm2gmx_modPE.pdb
cp $residuetypes .
gmx_mpi make_ndx -f $pdb -o index_dist.ndx <<eof
r 120
13
del 0-21
q
eof
gmx_mpi distance -f $pdb -s $pdb -oav GPE-POPC.xvg -n index_dist.ndx  -select "com of group 0 plus com of group 1"

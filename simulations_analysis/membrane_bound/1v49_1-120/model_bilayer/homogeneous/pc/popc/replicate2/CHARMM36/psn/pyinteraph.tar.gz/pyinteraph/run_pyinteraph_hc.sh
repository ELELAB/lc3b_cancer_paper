#!/bin/bash
. /usr/local/gromacs-5.1.5/bin/GMXRC.bash

. /usr/local/envs/pyinteraph/bin/activate

export PYINTERAPH=/usr/local/envs/pyinteraph/pyinteraph/
export PATH=$PATH:$PYINTERAPH

traj=protein.xtc
gro=confout_filtered.gro
pdb=frame0.pdb
dat=hc-graph.dat
datfilt=hc-graph_filt.dat


cd hc_cluster/5.125/
pyinteraph -s ../../$gro -t ../../../../filt_trjs/$traj -f --hc-graph $dat --ff-masses charmm27  --hc-co 5.125 --hc-residues ALA,ILE,LEU,VAL,PHE,TRP,MET,PRO > hc_cluster_5.125_c36_memb_r2.log  

#filtering 
filter_graph -d $dat -o $datfilt -t 20.0 > hc_cluster_5.125_filter_c36_memb_r2.log
#calculating hubs
graph_analysis -a $datfilt -r ../../../../frames/$pdb -u -ub hubs_c36_hc_cluster5.125_memb_r2.pdb -k 3 > c36_hc_cluster_5.125_hubs_memb_r2.log
#calculate_connected components
graph_analysis -a $datfilt -r ../../../../frames/$pdb -c -cb con_comp_c36_hc_cluster5.125_memb_r2.pdb > c36_hc_cluster_5.125_cc_memb_r2.log






#!/bin/bash

cd contact/5.125/paths/

head -123 10ARG-3SER/allpath/path.log | tail -2 >  contacts_paths_summary
head -123 11ARG-21ARG/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 49LYS-49LYS/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 51LYS-19ASP/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 53LEU-16ARG/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 53LEU-32PRO/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 53LEU-35ILE/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 53LEU-60MET/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 53LEU-89VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 53LEU-98VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 57HIS-32PRO/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 57HIS-35ILE/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 57HIS-60MET/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 57HIS-89VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 57HIS-98VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -123 70ARG-70ARG/allpath/path.log| tail -2 >>  contacts_paths_summary


cd ../../../hb/all/paths/

head -123 10ARG-113TYR/allpath/path.log | tail -2 >  hb_paths_summary
head -123 10ARG-16ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 10ARG-19ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 10ARG-21ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 10ARG-32PRO/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 10ARG-38TYR/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 10ARG-3SER/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 10ARG-56ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 10ARG-98VAL/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-113TYR/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-16ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-19ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-21ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-29THR/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-32PRO/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-38TYR/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-3SER/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-56ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 11ARG-98VAL/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 49LYS-49LYS/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-113TYR/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-16ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-19ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-21ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-32PRO/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-38TYR/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-3SER/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-56ASP/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 51LYS-98VAL/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 70ARG-60MET/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 70ARG-65LYS/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 70ARG-70ARG/allpath/path.log | tail -2 >>  hb_paths_summary
head -123 70ARG-91VAL/allpath/path.log | tail -2 >>  hb_paths_summary



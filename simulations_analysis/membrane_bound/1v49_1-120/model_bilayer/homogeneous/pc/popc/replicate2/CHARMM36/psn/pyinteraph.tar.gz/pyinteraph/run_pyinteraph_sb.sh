#!/bin/bash
. /usr/local/gromacs-5.1.5/bin/GMXRC.bash

. /usr/local/envs/pyinteraph/bin/activate

export PYINTERAPH=/usr/local/envs/pyinteraph/pyinteraph/
export PATH=$PATH:$PYINTERAPH

traj=protein.xtc
gro=confout_filtered.gro
pdb=frame0.pdb
dat=sb-graph.dat
datfilt=sb-graph_filt.dat


#hydrogen bond network 
cd sb/
pyinteraph -s ../../../frames/$pdb -t ../../../filt_trjs/$traj -r ../../../frames/$pdb --sb-co 4.5 -b --sb-graph sb-graph.dat --ff-masses charmm27 -v --sb-cg-file charged_groups.ini > sb_c36_memb_r2.log

#filtering 
filter_graph -d $dat -o $datfilt -t 20.0 > sb_filter_c36_memb_r2.log
#calculating hubs
graph_analysis -a $datfilt -r ../../../frames/$pdb -u -ub hubs_c36_sb_memb_r2.pdb -k 3 > c36_sb_hubs_memb_r2.log
#calculate_connected components
graph_analysis -a $datfilt -r ../../../frames/$pdb -c -cb con_comp_c36_sb_memb_r2.pdb > c36_sb_cc_memb_r2.log
#

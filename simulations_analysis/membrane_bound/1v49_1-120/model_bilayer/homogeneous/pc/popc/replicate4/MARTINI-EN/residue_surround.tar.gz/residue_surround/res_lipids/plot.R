############################################
library(ggplot2)
library(viridis)
library(reshape2)
library(tidyverse)
library(plyr)
################################################################################################################
################################################################################################################
atoms = read.table("all_res120.txt", header = FALSE, fill = TRUE)
atoms$V1 <- as.numeric(as.character(atoms$V1)) / 1000
atoms2 <- plyr::rename(atoms, c("V1"="time"))
atoms <- plyr::rename(atoms, c("V1"="time"))
atoms <- select(atoms, c(R = starts_with('V')))
library(dplyr)
atomsx<- bind_cols(atoms2['time'], atoms)
atomsxx<- atomsx[, colSums(atomsx != 0) > 0]
atomsxxx<- atomsxx[, (colSums(atomsxx>0)/nrow(atomsxx))*100 > 20]
atomsxxxx <- melt(atomsxxx, id.vars="time")
d <- rename(atomsxxxx, c("time"="time", "variable"="residue", "value"="num_of_atom"))
p <- ggplot(d, aes(x=time, y=num_of_atom, group=residue)) +
  geom_line(aes(color=residue)) +
  viridis::scale_color_viridis(discrete = TRUE) +
  labs(y="number of lipid atoms closer then 0.6 nm") +
  theme_classic() +
  xlab("time(ns)")
#p2 <- p + geom_hline(yintercept=0, linetype="dashed") + scale_x_continuous(limits = c(1, 151), expand = c(0,0), breaks=c(1, 25, 50, 75, 100, 125, 151))
ggsave("all_0.6.pdf",p, width=10, height=8, units="in", scale=1)
p2 <- p + facet_grid(residue ~ .) + theme(legend.position = "none")
ggsave("sep_0.6.pdf",p2, width=8, height=20, units="in")

#################################################################

#run the script plot.R to make a comparison plot of the calculated proximity between the protein and the membrane i.e. calculation of the number of lipid atoms in the surround of each residues of the protein
#include replicate 2-4 

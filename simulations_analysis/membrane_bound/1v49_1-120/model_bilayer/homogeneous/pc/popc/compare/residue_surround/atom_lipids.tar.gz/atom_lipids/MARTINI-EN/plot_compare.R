library(ggplot2)
library(viridis)
library(reshape2)
library(tidyverse)
library(plyr)
library(dplyr)

atomsrep2 = read.table("../../../../replicate2/MARTINI-EN/residue_surround/atom_lipids/all_res120.txt", header = FALSE, fill = TRUE)
atomsrep3 = read.table("../../../../replicate3/MARTINI-EN/residue_surround/atom_lipids/all_res120.txt", header = FALSE, fill = TRUE)
atomsrep4 = read.table("../../../../replicate4/MARTINI-EN/residue_surround/atom_lipids/all_res120.txt", header = FALSE, fill = TRUE)
#
atomsrep2$V1 <- as.numeric(as.character(atomsrep2$V1)) / 1000
atomsrep22 <- plyr::rename(atomsrep2, c("V1"="time"))
atomsrep2 <- plyr::rename(atomsrep2, c("V1"="time"))
atomsrep2 <- select(atomsrep2, c(R = starts_with('V')))
#
atomsrep3$V1 <- as.numeric(as.character(atomsrep3$V1)) / 1000
atomsrep32 <- plyr::rename(atomsrep3, c("V1"="time"))
atomsrep3 <- plyr::rename(atomsrep3, c("V1"="time"))
atomsrep3 <- select(atomsrep3, c(R = starts_with('V')))
#
atomsrep4$V1 <- as.numeric(as.character(atomsrep4$V1)) / 1000
atomsrep42 <- plyr::rename(atomsrep4, c("V1"="time"))
atomsrep4 <- plyr::rename(atomsrep4, c("V1"="time"))
atomsrep4 <- select(atomsrep4, c(R = starts_with('V')))
#
residue_index=1:120
for (i in residue_index){
 library(dplyr)
 atomsX_rep2x<- bind_cols(atomsrep22['time'], atomsrep2[i])
 colnames(atomsX_rep2x)[2] <- "rep2"
 xxx2 <- (colSums(atomsX_rep2x>0)/nrow(atomsX_rep2x))*100
 atomsX_rep3x<- bind_cols(atomsrep32['time'], atomsrep3[i])
 colnames(atomsX_rep3x)[2] <- "rep3"
 xxx3 <- (colSums(atomsX_rep3x>0)/nrow(atomsX_rep3x))*100
 atomsX_rep4x<- bind_cols(atomsrep42['time'], atomsrep4[i])
 colnames(atomsX_rep4x)[2] <- "rep4"
 xxx4 <- (colSums(atomsX_rep4x>0)/nrow(atomsX_rep4x))*100
 xxx2.2 <- xxx2 [2]
 xxx3.2 <- xxx3 [2]
 xxx4.2 <- xxx4 [2]
 #
 if (xxx2.2>=20||xxx3.2>=20||xxx4.2>=20) {
   print('Lets do a plot') 
   comparison_X_1 <- merge(atomsX_rep2x, atomsX_rep3x,  by="time", all = T)
   comparison_X_2 <- merge(comparison_X_1, atomsX_rep4x,  by="time", all = T)
   comparison_X_3x <- melt(comparison_X_2, id.vars="time")
   d <- rename(comparison_X_3x, c("time"="time", "variable"="replicate", "value"="num_of_atom"))
   p <- ggplot(d, aes(x=time, y=num_of_atom, group=replicate)) +
     geom_line(aes(color=replicate)) +
     viridis::scale_color_viridis(discrete = TRUE) +
     labs(y="number of lipid atoms closer then 0.6 nm") +
     theme_classic() +
     xlab("time(ns)")
   #ggsave(p, filename=paste("singlerep",i,"_0.6.pdf",sep=""), width=10, height=8, units="in", scale=1)
   p2 <- p + facet_grid(replicate ~ .) + theme(legend.position = "none")
   ggsave(p2, filename=paste("singlerep_sep",i,"_0.6.pdf",sep=""), width=8, height=15, units="in")
   } else  {
   print('Nothing to plot')
 }
}

################################################


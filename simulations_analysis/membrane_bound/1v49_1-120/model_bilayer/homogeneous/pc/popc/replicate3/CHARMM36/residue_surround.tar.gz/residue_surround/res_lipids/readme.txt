#We here calculated the proximity between the protein and the membrane i.e. calculation of the number of lipid atoms in the surround of each residues of the protein   
#always remember to have the right residuetypes.dat file in the local folder
#the calculation can be performed with the script residue_surround_res_lipids.sh 
#we then formatted the analysis results using the script plot.sh
#we then perform the plotting using the R script plot.R 

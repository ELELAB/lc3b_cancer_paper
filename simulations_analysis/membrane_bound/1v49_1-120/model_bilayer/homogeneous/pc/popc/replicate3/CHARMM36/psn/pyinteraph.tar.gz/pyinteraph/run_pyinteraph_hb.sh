#!/bin/bash
. /usr/local/gromacs-5.1.5/bin/GMXRC.bash

. /usr/local/envs/pyinteraph/bin/activate

export PYINTERAPH=/usr/local/envs/pyinteraph/pyinteraph/
export PATH=$PATH:$PYINTERAPH


traj=protein.xtc
gro=confout_filtered.gro
pdb=frame0.pdb
dat=hb-graph.dat
datfilt=hb-graph_filt.dat


#hydrogen bond network 
cd hb/all/
pyinteraph -s ../../../../frames/$pdb -t ../../../../filt_trjs/$traj -r ../../../../frames/$pdb -y --hb-graph hb-graph.dat --ff-masses charmm27  --hb-dat hb-dat --hb-class all > hb_all_c36_memb_r3.log 
#filtering 
filter_graph -d $dat -o $datfilt -t 20.0 > hb_all_filter_c36_memb_r3.log
#calculating hubs
graph_analysis -a $datfilt -r ../../../../frames/$pdb -u -ub hubs_c36_hb_all_memb_r3.pdb -k 3 > c36_hb_all_hubs_memb_r3.log 
#calculate_connected components
graph_analysis -a $datfilt -r ../../../../frames/$pdb -c -cb con_comp_c36_hb_all_memb_r3.pdb > c36_hb_all_cc_memb_r3.log

cd ../../hb/sc/
pyinteraph -s ../../../../frames/$pdb -t ../../../../filt_trjs/$traj -r ../../../../frames/$pdb -y --hb-graph hb-graph.dat --ff-masses charmm27  --hb-dat hb-dat --hb-class sc-sc > hb_sc_c36_memb_r3.log 

#filtering 
filter_graph -d $dat -o $datfilt -t 20.0 > hb_sc_filter_c36_memb_r3.log
#calculating hubs
graph_analysis -a $datfilt -r ../../../../frames/$pdb -u -ub hubs_c36_hb_sc_memb_r3.pdb -k 3 > c36_hb_sc_hubs_memb_r3.log
#calculate_connected components
graph_analysis -a $datfilt -r ../../../../frames/$pdb -c -cb con_comp_c36_hb_sc_memb_r3.pdb > c36_hb_sc_cc_memb_r3.log


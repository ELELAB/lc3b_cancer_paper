#!/bin/bash
#script to have a full dataframe of the residue surround values for the plotting
j=0
for ((i=1; i <=120; i++)); do
cd $i
cp $i.POPC.atoms.xvg $i.POPC.atoms.xvg.mod1
sed '/^#/ d'  $i.POPC.atoms.xvg.mod1 > $i.POPC.atoms.xvg.mod2
sed '/^@/ d'  $i.POPC.atoms.xvg.mod2 > $i.POPC.atoms.xvg.mod3
awk '{ print $1 }' 1.POPC.atoms.xvg.mod3 > ../try0
awk -v var="$i.POPC.atoms.xvg.mod3" '{f1 = $0; getline<var; print f1, $2}' < ../try$j > ../try$i
rm *POPC.atoms.xvg.mod*
cd ..
j=$(($j+1))
done
mv try120 all_res120.txt
rm try*
#then run the R script plot.R which will produce two files:i) sep_0.6.pdf ii) all_0.6.pdf that contain the values (i.e. number of lipid atoms) calculated 
#for each residue in a sourround of 0.6 Ang around their center of mass and represented in separated plots or a single one, respectively.
#The residue are filtered showing only the ones that have at lest one atom of the membrane lipids in their surround in the 20% or more of the frames of the trajectory

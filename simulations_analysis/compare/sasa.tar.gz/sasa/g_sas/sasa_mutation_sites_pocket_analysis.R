


####################################
library(tidyverse)
library(ggplot2)
library(sp)
library(viridis)
library(reshape2)
library(plyr)
library(MASS)
################################################################################################################

#boxplot

df1 = read.table("../../../membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate2/CHARMM36/sasa/g_sas/with_membrane/area.xvg", header = FALSE, fill = TRUE)
df1$V1 <- df1$V1/1000
colnames(df1) <- c("time","total_sasa_r2","S3_r2","R16_r2","D19_r2","R21_r2","P28_r2","T29_r2",
                   "P32_r2","I35_r2","R37_r2","Y38_r2","K39_r2","K49_r2","D56_r2","M60_r2","K65_r2",
                   "R70_r2","L82_r2","V89_r2","V91_r2","V98_r2","Y113_r2","G120_r2",
                   "D19_r2","I23_r2","P32_r2","I34_r2","K51_r2","L53_r2","F108_r2",
                   "F52_r2","V54_r2","P55_r2","L63_r2","I66_r2","I67_r2",
                   "L47_r2","D48_r2","K49_r2",
                   "K8_r2","L44_r2","R70_r2")
df1nom = read.table("../../../membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate2/CHARMM36/sasa/g_sas/without_membrane/area.xvg", header = FALSE, fill = TRUE)
df1nom$V1 <- df1nom$V1/1000
colnames(df1nom) <- c("time","total_sasa_r2no_m","S3_r2no_m","R16_r2no_m","D19_r2no_m","R21_r2no_m","P28_r2no_m","T29_r2no_m",
                   "P32_r2no_m","I35_r2no_m","R37_r2no_m","Y38_r2no_m","K39_r2no_m","K49_r2no_m","D56_r2no_m","M60_r2no_m","K65_r2no_m",
                   "R70_r2no_m","L82_r2no_m","V89_r2no_m","V91_r2no_m","V98_r2no_m","Y113_r2no_m","G120_r2no_m",
                   "D19_r2no_m","I23_r2no_m","P32_r2no_m","I34_r2no_m","K51_r2no_m","L53_r2no_m","F108_r2no_m",
                   "F52_r2no_m","V54_r2no_m","P55_r2no_m","L63_r2no_m","I66_r2no_m","I67_r2no_m",
                   "L47_r2no_m","D48_r2no_m","K49_r2no_m",
                   "K8_r2no_m","L44_r2no_m","R70_r2no_m")



df2 = read.table("../../../membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate3/CHARMM36/sasa/g_sas/with_membrane/area.xvg", header = FALSE, fill = TRUE)
df2$V1 <- df2$V1/1000
colnames(df2) <- c("time","total_sasa_r3","S3_r3","R16_r3","D19_r3","R21_r3","P28_r3","T29_r3",
                   "P32_r3","I35_r3","R37_r3","Y38_r3","K39_r3","K49_r3","D56_r3","M60_r3","K65_r3",
                   "R70_r3","L82_r3","V89_r3","V91_r3","V98_r3","Y113_r3","G120_r3",
                   "D19_r3","I23_r3","P32_r3","I34_r3","K51_r3","L53_r3","F108_r3",
                   "F52_r3","V54_r3","P55_r3","L63_r3","I66_r3","I67_r3",
                   "L47_r3","D48_r3","K49_r3",
                   "K8_r3","L44_r3","R70_r3")
df2nom = read.table("../../../membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate3/CHARMM36/sasa/g_sas/without_membrane/area.xvg", header = FALSE, fill = TRUE)
df2nom$V1 <- df2nom$V1/1000
colnames(df2nom) <- c("time","total_sasa_r3no_m","S3_r3no_m","R16_r3no_m","D19_r3no_m","R21_r3no_m","P28_r3no_m","T29_r3no_m",
                      "P32_r3no_m","I35_r3no_m","R37_r3no_m","Y38_r3no_m","K39_r3no_m","K49_r3no_m","D56_r3no_m","M60_r3no_m","K65_r3no_m",
                      "R70_r3no_m","L82_r3no_m","V89_r3no_m","V91_r3no_m","V98_r3no_m","Y113_r3no_m","G120_r3no_m",
                      "D19_r3no_m","I23_r3no_m","P32_r3no_m","I34_r3no_m","K51_r3no_m","L53_r3no_m","F108_r3no_m",
                      "F52_r3no_m","V54_r3no_m","P55_r3no_m","L63_r3no_m","I66_r3no_m","I67_r3no_m",
                      "L47_r3no_m","D48_r3no_m","K49_r3no_m",
                      "K8_r3no_m","L44_r3no_m","R70_r3no_m")



df3 = read.table("../../../membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate4/CHARMM36/sasa/g_sas/with_membrane/area.xvg", header = FALSE, fill = TRUE)
df3$V1 <- df3$V1/1000
colnames(df3) <- c("time","total_sasa_r4","S3_r4","R16_r4","D19_r4","R21_r4","P28_r4","T29_r4",
                   "P32_r4","I35_r4","R37_r4","Y38_r4","K39_r4","K49_r4","D56_r4","M60_r4","K65_r4",
                   "R70_r4","L82_r4","V89_r4","V91_r4","V98_r4","Y113_r4","G120_r4",
                   "D19_r4","I23_r4","P32_r4","I34_r4","K51_r4","L53_r4","F108_r4",
                   "F52_r4","V54_r4","P55_r4","L63_r4","I66_r4","I67_r4",
                   "L47_r4","D48_r4","K49_r4",
                   "K8_r4","L44_r4","R70_r4")
df3nom = read.table("../../../membrane_bound/1v49_1-120/model_bilayer/homogeneous/pc/popc/replicate4/CHARMM36/sasa/g_sas/without_membrane/area.xvg", header = FALSE, fill = TRUE)
df3nom$V1 <- df3nom$V1/1000
colnames(df3nom) <- c("time","total_sasa_r4no_m","S3_r4no_m","R16_r4no_m","D19_r4no_m","R21_r4no_m","P28_r4no_m","T29_r4no_m",
                      "P32_r4no_m","I35_r4no_m","R37_r4no_m","Y38_r4no_m","K39_r4no_m","K49_r4no_m","D56_r4no_m","M60_r4no_m","K65_r4no_m",
                      "R70_r4no_m","L82_r4no_m","V89_r4no_m","V91_r4no_m","V98_r4no_m","Y113_r4no_m","G120_r4no_m",
                      "D19_r4no_m","I23_r4no_m","P32_r4no_m","I34_r4no_m","K51_r4no_m","L53_r4no_m","F108_r4no_m",
                      "F52_r4no_m","V54_r4no_m","P55_r4no_m","L63_r4no_m","I66_r4no_m","I67_r4no_m",
                      "L47_r4no_m","D48_r4no_m","K49_r4no_m",
                      "K8_r4no_m","L44_r4no_m","R70_r4no_m")




#df4 = read.table("/Users/Matteo/Dropbox (ELELAB)/lc3b_burcu/REVISIONS_AUTOPHAGY/new_data/sasa/CHARMM36/membrane/replicate5/with_membrane/area.xvg", header = FALSE, fill = TRUE)
#df4$V1 <- df4$V1/1000
#colnames(df4) <- c("time","total_sasa_r5","R16_r5","D19_r5","R21_r5","P28_r5","T29_r5",
#                   "P32_r5","I35_r5","R37_r5","Y38_r5","K39_r5","K49_r5","D56_r5","M60_r5","K65_r5",
#                   "R70_r5","L82_r5","V89_r5","V91_r5","V98_r5","Y113_r5","G120_r5",
#                   "D19_r5","I23_r5","P32_r5","I34_r5","K51_r5","L53_r5","F108_r5",
#                   "F52_r5","V54_r5","P55_r5","L63_r5","I66_r5","I67_r5",
#                   "L47_r5","D48_r5","K49_r5",
#                   "K8_r5","L44_r5","R70_r5")
#df4nom = read.table("/Users/Matteo/Dropbox (ELELAB)/lc3b_burcu/REVISIONS_AUTOPHAGY/new_data/sasa/CHARMM36/membrane/replicate5/without_membrane/area.xvg", header = FALSE, fill = TRUE)
#df4nom$V1 <- df4nom$V1/1000
#colnames(df4nom) <- c("time","total_sasa_r5no_m","R16_r5no_m","D19_r5no_m","R21_r5no_m","P28_r5no_m","T29_r5no_m",
#                      "P32_r5no_m","I35_r5no_m","R37_r5no_m","Y38_r5no_m","K39_r5no_m","K49_r5no_m","D56_r5no_m","M60_r5no_m","K65_r5no_m",
#                      "R70_r5no_m","L82_r5no_m","V89_r5no_m","V91_r5no_m","V98_r5no_m","Y113_r5no_m","G120_r5no_m",
#                      "D19_r5no_m","I23_r5no_m","P32_r5no_m","I34_r5no_m","K51_r5no_m","L53_r5no_m","F108_r5no_m",
#                      "F52_r5no_m","V54_r5no_m","P55_r5no_m","L63_r5no_m","I66_r5no_m","I67_r5no_m",
#                      "L47_r5no_m","D48_r5no_m","K49_r5no_m",
#                      "K8_r5no_m","L44_r5no_m","R70_r5no_m")


df5 = read.table("../../../free/1v49_1-120/replicate1/CHARMM36/sasa/g_sas/free/area.xvg", header = FALSE, fill = TRUE)
df5$V1 <- df5$V1/1000
colnames(df5) <- c("time","total_sasa_f","S3_f","R16_f","D19_f","R21_f","P28_f","T29_f",
                   "P32_f","I35_f","R37_f","Y38_f","K39_f","K49_f","D56_f","M60_f","K65_f",
                   "R70_f","L82_f","V89_f","V91_f","V98_f","Y113_f","G120_f",
                   "D19_f","I23_f","P32_f","I34_f","K51_f","L53_f","F108_f",
                   "F52_f","V54_f","P55_f","L63_f","I66_f","I67_f",
                   "L47_f","D48_f","K49_f",
                   "K8_f","L44_f","R70_f")


all1 <- merge(df1, df2, by="time", all = T)
all2 <- merge(all1, df3,  by="time", all = T)
all4 <- merge(all2, df5,  by="time", all = T)
all5 <- merge(all4, df1nom,  by="time", all = T)
all6 <- merge(all5, df2nom,  by="time", all = T)
all8 <- merge(all6, df3nom,  by="time", all = T)

v <- c("S3","R16","D19","R21","P28","T29",
       "P32","I35","R37","Y38","K39","K49","D56","M60","K65",
       "R70","L82","V89","V91","V98","Y113","G120",
       "I23","I34","K51","L53","F108",
       "F52","V54","P55","L63","I66","I67",
       "L47","D48",
       "K8","L44")
refff <- c("rep1(memb)", "rep2(memb)", "rep3(memb)","rep1(no memb)", "rep2(no memb)","rep3(no memb)","free")
for(i in 1:38) {
  res <- subset(all8, select=c("time",paste0(v[i],"_r2"),paste0(v[i],"_r3"),paste0(v[i],"_r4"),paste0(v[i],"_r2no_m"),paste0(v[i],"_r3no_m"),paste0(v[i],"_r4no_m"),paste0(v[i],"_f")))
  res <- melt(res, id.vars="time")
  res <- rename(res, c("time"="time", "variable"="replicate", "value"="SASA"))
  k<- ggplot(res, aes(x=replicate, y=SASA, fill=replicate), show.legend = FALSE) +
    geom_boxplot() +
    scale_fill_manual(values=c("#481567FF","#3B528BFF","#FDE725FF","#481567FF","#3B528BFF","#FDE725FF","#7e4e90ff")) +
    labs(y="Solvent accessible surface area (nm2)") +
    theme_classic(base_size = 18) +
    theme(legend.position = "none") +
    theme(axis.text.x = element_text(angle = 90)) +
    scale_x_discrete(labels= refff)
  ggsave(filename=paste("Sasa_",v[i],".pdf"),k, width=9, height=8, units="in")
} 

#res <- subset(all8, select=c("time","S3_r2", "S3_r3", "S3_r4", "S3_r2no_m", "S3_r3no_m", "S3_r4no_m", "S3_f"))
#res <- melt(res, id.vars="time")
#res <- rename(res, c("time"="time", "variable"="replicate", "value"="SASA"))
#refff <- c("rep1(memb)", "rep2(memb)", "rep3(memb)", "rep1(no memb)", "rep2(no memb)","rep3(no memb)","free")
#k<- ggplot(res, aes(x=replicate, y=SASA, fill=replicate), show.legend = FALSE) +
#  geom_boxplot() +
#  scale_fill_manual(values=c("#481567FF", "#3B528BFF", "#29AF7FFF", "#481567FF", "#3B528BFF", "#29AF7FFF", "#7e4e90ff")) +
#  labs(y="Solvent accessible surface area (nm2)") +
#  theme_classic(base_size = 18) +
#  theme(legend.position = "none", axis.text.x = element_text(angle = 90)) +
#  scale_x_discrete(labels= refff)
#ggsave(filename=paste("Sasa_S3.pdf"),k, width=9, height=8, units="in")




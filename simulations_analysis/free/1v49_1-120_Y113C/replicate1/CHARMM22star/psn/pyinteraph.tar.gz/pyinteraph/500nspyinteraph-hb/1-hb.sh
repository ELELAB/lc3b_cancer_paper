#source the gromacs for pyinteraph analysis
source /usr/local/gromacs-5.1.5/bin/GMXRC.bash
#copy the charged_group.ini from old folder lir_tfg
cp ../../../../../../../../../../lir_tfg/simulations_analysis/LC3C/TFG_ATG13/model_maxg/analysis/pyinteraph/pyinteraph-hb/hydrogen_bonds.ini .
#created the symbolic linc for central trajectory and update.gro file

#ln -s ../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/center_traj.xtc
ln -s ../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/center_traj.xtc 

#ln -s ../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/update.gro
ln -s ../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/update.gro 

#created the ini.pdb for downstream analysis
gmx editconf -f update.gro -o ini.pdb
#activated the path for pyinteraph analysis
workon pyinteraph
# performed the pyinteraph analysis for salt bridge interactions

pyinteraph -s ini.pdb -t center_traj.xtc -r ini.pdb --hb-class all  -y --hb-graph hb-graph.dat --ff-masses charmm27 -v --hb-ad-file hydrogen_bonds.ini

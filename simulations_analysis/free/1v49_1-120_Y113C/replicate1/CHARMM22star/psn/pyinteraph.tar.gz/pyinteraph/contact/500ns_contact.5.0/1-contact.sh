#!/bin/bash

source /usr/local/gromacs-5.1.5/bin/GMXRC.bash
#copy the scripts from ULK1 folder
#cp ../../../../../../../../../../../ulk1/simulations/wt/analysis/c22star/5-pyinteraph/contact/contact.5.0/*.sh .

#created the symbolic link update.gro file
#ln -s ../../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/update.gro 
ln -s ../../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/update.gro 

#created symbolic link for trajectory file
#ln -s ../../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/center_traj.xtc
ln -s ../../../../../../../../../../simulations/lc3b/free/1v49_1-120_Y113C/replicate1/CHARMM22star/9-md/Mol_An/center_traj.xtc 

# created the pdb by gmx editconf
gmx editconf -f update.gro -o update.pdb
#traj="../../../../../md/c22star/9-md/Mol_An/center_traj.xtc"
#pdb="../../../../md/c22star/9-md/Mol_An/update.gro"
#pdb="update.pdb"
#activated the system for pyinterpah analysis
workon pyinteraph

#as a default it will use all hbonds #hydrophobic 
#all
pyinteraph -v -s update.pdb -t center_traj.xtc -r update.pdb -f --hc-graph contact.dat --hc-co 5 --ff-masses charmm27 --hc-residues ALA,CYS,ILE,LEU,VAL,PHE,TRP,TYR,MET,PRO,HIS,LYS,ARG,GLU,ASP,ASN,GLN,SER,THR

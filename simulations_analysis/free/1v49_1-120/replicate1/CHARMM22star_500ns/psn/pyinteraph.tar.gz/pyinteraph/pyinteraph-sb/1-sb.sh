#source the gromacs for pyinteraph analysis
source /usr/local/gromacs-5.1.5/bin/GMXRC.bash
#copy the charged_group.ini from old folder lir_tfg

cp ../../../../../../1v49_1-120_Y113C/replicate1/CHARMM22star/psn/pyinteraph/pyinteraph-sb/charged_groups.ini .

#created the symbolic linc for central trajectory and update.gro file

ln -s ../../../../../../../../../simulations/lc3b/free/1v49_1-120/replicate1/CHARMM22star/md_500ns/Mol_An/update.gro
#created symbolic link for trajectory file

ln -s ../../../../../../../../../simulations/lc3b/free/1v49_1-120/replicate1/CHARMM22star/md_500ns/Mol_An/center_traj_500ns.xtc

#created the ini.pdb for downstream analysis
gmx editconf -f update.gro -o ini.pdb
#activated the path for pyinteraph analysis
workon pyinteraph
# performed the pyinteraph analysis for salt bridge interactions

pyinteraph -s ini.pdb -t center_traj_500ns.xtc -r ini.pdb --sb-co 4.5 -b --sb-graph sb-graph.dat --ff-masses charmm27 -v --sb-cg-file charged_groups.ini

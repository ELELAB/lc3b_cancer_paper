rm -f *.pdf *.dat merged.xtc rmsd.dat rmsd.xvg rmsd.xpm

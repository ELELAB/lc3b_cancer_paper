. ../../force_fields.sh

nmr_exp_encoding="../../../exp_ref/structural_alphabet/lf_str.out"

# for each MD simulation
freq_files=""
for i in ${ffs[@]}; do
	
	# convert the full SA to reduced SA
	./full2reduced ../../${i}/structural_alphabet/lf_str.out -o lf_str_reduced_${i}.dat

	# calculate per-position letter frequencies
	./encoding2frequencies lf_str_reduced_${i}.dat -o freqs_${i}.dat
	freq_files="${freq_files} freqs_${i}.dat"; 
done

# Same as before for the experimental reference structure
./full2reduced ${nmr_exp_encoding} -o lf_str_reduced_1v49.dat
./encoding2frequencies lf_str_reduced_1v49.dat -o freqs_1v49.dat


# plot per-fragment letter frequencies
./plot_frequencies $freq_files freqs_1v49.dat \
                   -w 2 -l 6 -s 10 5 -f 1 -S 7\
                   -b ${ff_labels[@]} "NMR (1V49)"

# calculate per-fragment Jensen-Shannon divergence between probability
# distributions derived from the calculated frequencies
./js_divergence $freq_files freqs_1v49.dat
./plot_jsd JSd*.dat -d natural \
           -w 3 -l 3 -s 10 14 -f 1 -L -t Fragment \
           -b ${ff_labels[@]} "NMR (1V49)"


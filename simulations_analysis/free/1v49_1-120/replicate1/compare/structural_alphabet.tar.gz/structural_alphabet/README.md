# Introduction

This folder contains the analysis of local motions by using a structural
alphabet (SA), as detailed in the paper. Briefly, each conformation of each MD
trajectory is converted to an string using a structural aphabet definition; from
these, the frequency of each letter for each protein fragment is calculated for
every simulation and these are used as discrete probability distributions to be
compared using Jensen-Shannon divergence. A similar analysis is also performed
on a NMR-resolved structure of LC3B (PDB ID 1V49) in its own directory.

The analysis is performed after converting the full alphabet strings
to a reduced alphabet of only 6 letters which represent the most relevant
conformations, as for the reduced structural alphabet definition (see paper).

# Requirements

This folder provides Python scripts that perform the analysis and plotting.
Please see the environment.txt file for the necessary Python packages - the
scripts have been run using Python 3.7.5.

You also need to have run the single structural alphabet analysis for each
force-field and experimental reference directory. These just calculate the SA
encoding for each protein frame, in each simulation.

# Running

Run the do.sh bash script.


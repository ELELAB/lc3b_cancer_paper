#you have to uncomment the input/output file lines in the *R file (Input: the *dat file you want to process)
Rscript CS_convert_format_lc3b.R

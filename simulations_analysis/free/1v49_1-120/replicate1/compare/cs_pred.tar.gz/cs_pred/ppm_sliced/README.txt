
# bb_predict.dat file of the ppm analysis carried out are copied from each force field's directory
# An example for CHARMM22star is given here:
cp -p ../../../CHARMM22star/cs_pred/ppm/bb_predict.dat bb_predict_charmm22star.dat 


# The ppm output files bb_predict.dat for each force field were renamed as bb_predict_ff1.dat,bb_predict_ff2.dat and are put together in the working directory
# The R script ppm_sliceatoms_n_calcerror.R is executed to slice the *dat files in the folder to individual atom files
# The experimental and ppm predicted CS values are compared. Root Mean Squared Error (RMSE) and Mean Absolute Error (MAE) tables are given as outputs
./run_ppm_sliced_atoms.sh


# The R script CS_convert_format_lc3b.R is executed to convert the *dat files in the folder to SHIFTY format
./run_convert2shifty.sh

# The files in the SHIFTY format are written with *.CS_SHIFTY.txt extension and uploaded to d2D server http://www-mvsoftware.ch.cam.ac.uk/index.php/d2D/d2Drun 
# The server requires the CS data files to be in SHIFTY format and with *.txt extension
# The output files from the server were saved in the folder as *_delta2D.txt


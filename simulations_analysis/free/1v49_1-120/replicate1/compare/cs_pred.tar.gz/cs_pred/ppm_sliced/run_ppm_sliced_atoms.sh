#The input files (that should have the *dat extension) are read in a loop in the *R file (the *dat files you want to process)
Rscript ppm_sliceatoms_n_calcerror.R

#!/bin/bash

cd contact/5.5/paths

head -124 11ARG-19ASP/allpath/path.log | tail -2 >  contacts_paths_summary
head -124 49LYS-113TYR/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-16ARG/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-32PRO/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-35ILE/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-38TYR/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-56ASP/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-60MET/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-65LYS/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-82LEU/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-89VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-91VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 49LYS-98VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-113TYR/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-16ARG/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-21ARG/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-29THR/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-32PRO/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-35ILE/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-49LYS/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-56ASP/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-60MET/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-65LYS/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-89VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-91VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 53LEU-98VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-113TYR/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-16ARG/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-28PRO/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-29THR/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-32PRO/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-35ILE/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-49LYS/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-56ASP/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-60MET/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-65LYS/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-89VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-91VAL/allpath/path.log| tail -2 >>  contacts_paths_summary
head -124 57HIS-98VAL/allpath/path.log| tail -2 >>  contacts_paths_summary




cd hb/all/paths

head -124 10ARG-113TYR/allpath/path.log | tail -2 >  hb_paths_summary
head -124 10ARG-120GLY/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-16ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-19ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-21ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-29THR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-32PRO/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-37ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-38TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-3SER/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-49LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-56ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-70ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 10ARG-98VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-113TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-120GLY/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-16ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-19ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-21ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-29THR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-32PRO/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-37ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-38TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-3SER/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-49LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-56ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-60MET/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-65LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-70ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-91VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 11ARG-98VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-113TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-120GLY/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-16ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-19ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-21ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-29THR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-32PRO/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-38TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-3SER/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-56ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-60MET/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-65LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-70ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-91VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 49LYS-98VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-113TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-120GLY/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-16ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-19ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-21ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-29THR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-32PRO/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-37ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-38TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-3SER/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-49LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-56ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-60MET/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-65LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-70ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-91VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 51LYS-98VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-113TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-16ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-19ASP/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-21ARG/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-38TYR/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-3SER/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-49LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-60MET/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-65LYS/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-91VAL/allpath/path.log| tail -2 >>  hb_paths_summary
head -124 70ARG-98VAL/allpath/path.log| tail -2 >>  hb_paths_summary





#!/bin/bash

cd contact/5.125/paths

head -124 11ARG-19ASP/allpath/path.log | tail -2 >  contacts_paths_summary
head -124 49LYS-35ILE/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 49LYS-60MET/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 49LYS-65LYS/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 49LYS-89VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 49LYS-91VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 49LYS-98VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-32PRO/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-35ILE/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-49LYS/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-60MET/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-65LYS/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-89VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-91VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 53LEU-98VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-32PRO/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-35ILE/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-49LYS/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-60MET/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-65LYS/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-89VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-91VAL/allpath/path.log | tail -2 >>  contacts_paths_summary
head -124 57HIS-98VAL/allpath/path.log | tail -2 >>  contacts_paths_summary


